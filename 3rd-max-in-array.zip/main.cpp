#include <iostream>
#include <vector>
#include <climits>
using namespace std;

// int findMaxInt(int foo[], int length){
// 	int prev1 = 0, prev2 = 0, prev3 = 0;
// 	for(int i = 0; i < length; i ++){
// 		if(foo[i] > prev1){
// 			prev3 = prev2;
// 			prev2 = prev1;
// 			prev1 = foo[i];
// 		}
// 		else if(foo[i] > prev2){
// 			prev3 = prev2;
// 			prev2 = foo[i];
// 		}
// 		else if(foo[i] > prev3){
// 			prev3 = foo[i];
// 		}
// 	}
// 	return prev1;
// }

// vector<int> findMaxN(int foo[], int length){
// 	vector<int> top;
// 	int prev1 = 0, prev2 = 0, prev3 = 0;
// 	for(int i = 0; i < length; i ++){
// 		if(foo[i] > prev1){
// 			prev3 = prev2;
// 			prev2 = prev1;
// 			prev1 = foo[i];
// 		}
// 		else if(foo[i] > prev2){
// 			prev3 = prev2;
// 			prev2 = foo[i];
// 		}
// 		else if(foo[i] > prev3){
// 			prev3 = foo[i];
// 		}
// 	}
// 	top.push_back(prev1);
// 	top.push_back(prev2);
// 	top.push_back(prev3);
// 	return top;
// }

// void printVector(vector<int> foo){
// 	for(auto i : foo){
// 		cout << i << " ";
// 	}
// }


/* Solution */
/*
	20 40 60

	now next number is 60 
	1st branch fails 
	2nd branch pass ! problem is here 
	according to ur algo it will then become  40 60 60

	PROBLEM IS THE CONDITIONS NOT TIGHT ENOUGH ! and so it lets case that's not suppose to be true becomes true
*/
int thirdMax(vector<int>& nums) {
	int  firstMax = INT32_MIN, secondMax = INT32_MIN, thirdMax = INT32_MIN; 
	for(int i = 0; i < nums.size(); i++){
		//Branch 1 
		if(nums[i] > firstMax){ //insert at beginning
			thirdMax = secondMax;
			secondMax = firstMax;
			firstMax = nums[i];
		}
		//Branch 2 
		else if(nums[i] > secondMax && nums[i] != firstMax){ //insert after 1st
			thirdMax = secondMax;
			secondMax = nums[i];
		}
		//Branch 3 
		else if((nums[i] > thirdMax) && (nums[i] != secondMax) && (nums[i] != firstMax)){ //insert after 2nd
			thirdMax = nums[i];
		}
	}
	cout << firstMax << " , " << secondMax << " , " << thirdMax << endl;
	if(((secondMax == INT32_MIN) && (firstMax != INT32_MIN)) || (thirdMax == INT32_MIN)){
		return firstMax;
	}
	else if ((thirdMax == INT32_MIN) && (secondMax != INT32_MIN)){
		return secondMax;	
	}
	else return thirdMax;
}

//-2147483648 0 0

//Given a non-empty array of integers, return the third maximum number in this array.
//If it does not exist, return the maximum number. The time complexity must be in O(n).
int main() {
	vector<int> nums = {1,2,-2147483648};
	cout << thirdMax(nums) << endl;
}

// 3 2 1