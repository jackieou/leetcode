#include <iostream>
#include <string>
using namespace std;

void printUnitTimes(char letter,int times){
	for(int i = 0; i < times; i++){
		cout << letter;
	}
}

string intToRoman(int s) {
	string res = "";
	int times;

	while(s != 0){
		if(s - 1000 >= 0){
			times = s/1000;
			printUnitTimes('M', times); //add to vector? cuz function wants to return a string not cout
			s -= times*1000;
		}
		else if(s - 500 >= 0){
			if(s == 900){
				cout << "CM"; //add to vector? cuz function wants to return a string not cout
				s -= 900;
			}
			else{
				times = s/500;
				printUnitTimes('D', times); //add to vector? cuz function wants to return a string not cout
				s -= times*500;
			}
		}
		else if(s - 100 >= 0){
			if(s == 400){
				cout << "CD"; //add to vector? cuz function wants to return a string not cout
				s -= 400;
			}
			else{
				times = s/100;
				printUnitTimes('C', times); //add to vector? cuz function wants to return a string not cout
				s -= times*100;
			}
		}
		else if(s - 50 >= 0){
			if(s == 90){
				cout << "LC"; //add to vector? cuz function wants to return a string not cout
				s -= 90;
			}
			else{
				times = s/50;
				printUnitTimes('L', times); //add to vector? cuz function wants to return a string not cout
				s -= times*50;
			}
		}
		else if(s - 10 >= 0){
			if(s == 40){
				cout << "XL"; //add to vector? cuz function wants to return a string not cout
				s -= 40;
			}
			else{
				times = s/10;
				printUnitTimes('X', times); //add to vector? cuz function wants to return a string not cout
				s -= times*10;
			}
		}
		else if(s - 5 >= 0){
			if(s == 9){
				cout << "IX"; //add to vector? cuz function wants to return a string not cout
				s -= 9;
			}
			else{
				times = s/5;
				printUnitTimes('V', times); //add to vector? cuz function wants to return a string not cout
				s -= times*5;
			}
		}
		else if(s - 1 >= 0){
			if(s == 4){
				cout << "IV"; //add to vector? cuz function wants to return a string not cout
				s -= 4;
			}
			else{
				printUnitTimes('I', s); //add to vector? cuz function wants to return a string not cout
				s = 0;
			}
		}
	}


	return res;
}

int main() {
	int integer = 123;

	cout << intToRoman(integer);
}

/*
I = 1
V = 5
X = 10
L = 50
C = 100
D = 500
M = 1000
*/