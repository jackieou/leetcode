#include <iostream>
#include <vector>
using namespace std;

bool isPalindrome(int x) {
	//make storage
	vector<int> storage;

	if(x < 0){
		return false;
	}
	//if pass here we can assume it is positive int

	while(x!=0){
		//extract each number
		int lastDigit = x % 10;
		//cout << "Last digit : " << lastDigit << endl;
		storage.push_back(lastDigit);

		//update the x
		x = (x - lastDigit)/10;
	}

	for(int i = 0; i < storage.size(); i++){
		//if not match return false
		//cout << "storage[i] = " << storage[i] << endl;
		//cout << "storage.at(storage.size() - 1) = " << storage.at(storage.size() - (i+1)) << endl;
		if(storage[i] != storage.at(storage.size() - 1-i)){
		 	return false;
		}
	}

    return true;
}

int main() {
	int integer = 1;
	//check if 0 then stop
	//cout << 121%10; //gives 1. then 121 - 1 = 120. then 120/10 = 12
	//cout << 12%10; //gives 2. then 12-2 = 10. then 10/10 = 1
	//cout << 1%10; // gives 1. then 1-1 = 0. then 0/10 = 0

	if(isPalindrome(integer)){
		cout << "YES";
	}else{
		cout << "NO";
	}
}